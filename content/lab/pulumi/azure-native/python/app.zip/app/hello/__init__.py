def main(req):
     user = req.params.get('user')
     logging.info('Python HTTP trigger function processed a request.')
     return f' Hello, {user}!, You have successfully deployed a Function App!'
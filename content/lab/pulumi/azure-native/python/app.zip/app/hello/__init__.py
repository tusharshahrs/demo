def main(req):
    return f'Hello, you have successfully deployed a Azure Function in Python!'
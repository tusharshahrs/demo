import logging
import azure.functions

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    name = "Pulumi Pulumi"
    return func.HttpResponse(f"Hello {name}!")
def main(req):
     logging.info('Python HTTP trigger function processed a request.')
     return "You've successfully deployed a Function App!"
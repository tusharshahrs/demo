# __init__.py
import azure.functions as func
import logging

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f'You have successfully deployed a Function App! {obj.read()}')
    return func.HttpResponse(f"You have successfully deployed a Function App via Pulumi")
def main(req):
    user = req.params.get('user')
    return f'Hello, you have successfully deployed a Azure Function in Python {user}!'